## LATEST CHANGELOG:

# Version 2.6.23/25
- Nothing much here. A couple of very small changes before embarking on a couple of big changes.

# Version 2.6.23/24
- Added "Use Fanart Background for Scraper Progress Display" to Settings->Results->Display.
- Added "Scrape with an Alias" to Playback Options. If aliases are available from the metadata, then you can choose for Fen to scrape using one of the aliases.
- Added "keyart" to metadata from fanart.tv. You will need to clear the metacache if you wish to see keyart immediately.
- Sources Folders now managed through Tools->Sources Folders Manager.
- Some minor changes to Extras window animations.
- Other changes/fixes.
